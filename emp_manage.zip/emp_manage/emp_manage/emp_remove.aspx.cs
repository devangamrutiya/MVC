﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace emp_manage
{
    public partial class WebForm3 : System.Web.UI.Page
    
   {
        string str = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\MCA\MCA-SEM2\ASP\Assignment\Employee_manage\emp_manage\emp_manage\App_Data\empdata.mdf;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        int id;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("emp_login.aspx");
            }
            else
            {
                getcon();
            }
            
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("Delete from [employee]  where Id = '" + ViewState["id"] + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            ScriptManager.RegisterStartupScript(this, GetType(), "displayalertmessage", "remove();", true);
            GridView1.DataBind();
        }
        protected void getcon()
        {
            con = new SqlConnection(str);
            con.Open();
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "cmd_dlt")
            {
                int rowindex = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridView1.Rows[rowindex];
                ViewState["id"] = row.Cells[0].Text.ToString();
                txtname.Text = row.Cells[1].Text.ToString();
                txtemail.Text = row.Cells[2].Text.ToString();
                txtphone.Text = row.Cells[3].Text.ToString();
                RadioListGender.SelectedValue = row.Cells[4].Text.ToString();
                txtsalary.Text = row.Cells[5].Text.ToString();
                DropDownListBuilding.SelectedValue = row.Cells[6].Text.ToString();
            }
        }
    }
}