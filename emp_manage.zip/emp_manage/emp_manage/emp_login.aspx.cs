﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace emp_manage
{
    public partial class emp_login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["user"] = null;
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            string str = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\MCA\MCA-SEM2\ASP\Assignment\Employee_manage\emp_manage\emp_manage\App_Data\empdata.mdf;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            try
            {

                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("select * from [emp_manage] ", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    if (dr.GetValue(1).ToString() == txtemail.Text.Trim() && dr.GetValue(2).ToString() == txtpassword.Text.Trim())
                    {
                        Session["user"] = dr.GetValue(1).ToString();
                        Response.Redirect("add_emp.aspx");
                    }
                    else
                    {
                        Response.Write("<script>alert('Login Failed')</script>");
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "displayalertmessage", "showError();", true);

                }
            }
            catch(Exception ex)
            {
                Response.Write("<script>alert('" + ex.ToString() + "')</script>");
            }
        }


    }
}
