﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace emp_manage
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string str= @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\MCA\MCA-SEM2\ASP\Assignment\Employee_manage\emp_manage\emp_manage\App_Data\empdata.mdf;Integrated Security=True";
        SqlConnection con;
        SqlDataAdapter da;
        SqlCommand cmd;
        DataSet ds;
        int id;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["user"]== null)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "displayalertmessage", "showInfo();", true);
                Response.Redirect("emp_login.aspx");
            }
            else
            {
                getcon();
            }

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            try
            {

            cmd = new SqlCommand("insert into employee(name,email,phone,gender,salary,city) values('" + txtname.Text + "','" + txtemail.Text + "','" + txtphone.Text + "','" + RadioListGender.SelectedValue + "','" + txtsalary.Text + "','" + DropDownListBuilding.SelectedValue + "')",con);
            cmd.ExecuteNonQuery();
            con.Close();
            ScriptManager.RegisterStartupScript(this, GetType(), "displayalertmessage", "sucess();", true);
            }
            catch(Exception ex)
            {
                Response.Write("<script>alert('" + ex.ToString() + "')</script>");
            }

        }
        protected void getcon()
        {
            con = new SqlConnection(str);
            con.Open();
        }
    }
}